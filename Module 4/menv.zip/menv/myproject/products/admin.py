from django.contrib import admin
from .models import ProductMst, ProductSubCat

admin.site.register(ProductMst)
admin.site.register(ProductSubCat)
